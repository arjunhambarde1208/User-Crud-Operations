package com.user.user.crud.operations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCrudOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
